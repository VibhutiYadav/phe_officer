class ProjectImages {
  static const Splash =  "assets/images/Splash.png";
  static const logo =  "assets/images/BlackLogo.png";
  static const mail =  "assets/images/mail.png";
  static const lock =  "assets/images/lock.png";
  static const HKBlack = "assets/images/HKBlack.png";
  static const rightArrow = "assets/images/rightArrow.png";
  static const home = "assets/images/home.png";
  static const darkhome = "assets/images/homeDark.png";
  static const user = "assets/images/user.png";
  static const userDark = "assets/images/userDark.png";
  static const file = "assets/images/file.png";
  static const usericon = "assets/images/userIcon.png";
  static const telephone = "assets/images/telephone.png";
  static const watermark = "assets/images/watermark.png";
  static const userIcon= "assets/images/userIcon.png";
  static const form= "assets/images/Form.png";
  static const location= "assets/images/location.png";
  static const calendar= "assets/images/calendar.png";
  static const camera= "assets/images/camera.png";
  static const mapImage = "assets/images/maps.jpg";
}